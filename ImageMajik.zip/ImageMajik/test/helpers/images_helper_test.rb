require 'test_helper'

class ImagesHelperTest < ActionView::TestCase
end
