require 'test_helper'

class HomepagesHelperTest < ActionView::TestCase
end
